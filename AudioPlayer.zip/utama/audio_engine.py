import vlc
from mutagen.flac import FLAC

class AudiophileEngine:
    def __init__(self):
        # '--quiet' biar terminal lu bersih dari spam log bawaan VLC
        self.instance = vlc.Instance('--no-xlib', '--quiet')
        self.player = self.instance.media_player_new()
        
        # Inisialisasi Equalizer VLC
        self.eq = vlc.AudioEqualizer()
        self.player.set_equalizer(self.eq)
        self.current_eq_amps = [0.0] * 10 

    def load_and_play(self, file_path):
        self.player.stop() 
        current_media = self.instance.media_new(file_path)
        self.player.set_media(current_media)
        self.player.set_equalizer(self.eq)
        self.player.play()

    def pause_resume(self):
        if self.player.is_playing():
            self.player.pause()
            return "paused"
        else:
            self.player.play()
            return "playing"

    def stop(self):
        self.player.stop()

    def is_finished(self):
        return str(self.player.get_state()) == "State.Ended"

    # --- SENSOR WAKTU & DURASI ---
    def get_time(self):
        return self.player.get_time()

    def get_length(self):
        return self.player.get_length()

    def set_time(self, ms_time):
        self.player.set_time(int(ms_time))

    # --- EQUALIZER & METADATA ---
    def set_custom_eq(self, band_index, amp_value):
        self.current_eq_amps[band_index] = amp_value
        self.eq.set_amp_at_index(amp_value, band_index)
        self.player.set_equalizer(self.eq)

    def extract_metadata(self, file_path):
        try:
            audio = FLAC(file_path)
            title = audio.get('title', ['Unknown Track'])[0]
            artist = audio.get('artist', ['Unknown Artist'])[0]
            sample_rate = audio.info.sample_rate / 1000 
            bit_depth = audio.info.bits_per_sample
            cover_data = audio.pictures[0].data if audio.pictures else None
            
            return {
                "title": title, "artist": artist, "format": "FLAC",
                "bit_depth": bit_depth, "sample_rate": sample_rate, "cover_bytes": cover_data
            }
        except Exception:
            return None