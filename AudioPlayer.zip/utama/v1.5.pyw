import customtkinter as ctk
import os
import io
import json
import colorsys
from PIL import Image
from audio_engine import AudiophileEngine
from smart_shuffle import SmartShuffle 
import customtkinter as ctk
import os
import ctypes # <--- TAMBAHIN INI

# KODE SAKTI BIAR ADAPTIF DI SEMUA MONITOR (4K / HIGH DPI)
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except Exception:
    ctypes.windll.user32.SetProcessDPIAware()
# ---------------------------------------------------------

import io
import json
# ... (sisa import lainnya)

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("dark-blue")

SETTINGS_FILE = "player_settings.json"

class AudiophilePlayer(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Smart Shuffle Player - Audiophile Edition")
        self.geometry("850x650")
        # Ganti 'music_icon.ico' dengan nama file icon lu
        try:
            self.iconbitmap("Dtafalonso-Win-10x-Music.ico")
        except:
            pass
        self.minsize(700, 550) 
        self.configure(fg_color="#000000")

        # Inisialisasi Mesin
        self.engine = AudiophileEngine() 
        self.shuffler = SmartShuffle()
        
        # State Variables
        self.current_playlist_files = [] 
        self.current_track_index = -1
        self.is_playing = False
        self.is_shuffle = False
        self.repeat_mode = 0 
        self.is_seeking = False 
        self.track_length_ms = 0
        self.sidebar_visible = True
        self.is_animating = False
        self.sidebar_offset = 0 
        self.more_window = None
        self.eq_window = None 
        self.resize_timer = None
        self.current_scale = 1.0 

        # Container Utama
        self.bg_container = ctk.CTkFrame(self, fg_color="#000000")
        self.bg_container.pack(fill="both", expand=True, padx=10, pady=10)

        self._build_ui()
        self._bind_events()

        self.set_cover_image(None)
        self.monitor_playback()
        self.load_settings()

    # ==========================================
    # UI BUILDER (MEMBANGUN TAMPILAN)
    # ==========================================
    def _build_ui(self):
        # --- 1. SIDEBAR ---
        self.sidebar_frame = ctk.CTkFrame(self.bg_container, width=250, corner_radius=20, fg_color="#121212")
        self.sidebar_frame.grid_propagate(False) 
        self.sidebar_frame.pack_propagate(False)

        self.logo_label = ctk.CTkLabel(self.sidebar_frame, text="🎵 Library", font=ctk.CTkFont(size=20, weight="bold"))
        self.logo_label.pack(pady=(25, 15), padx=20, anchor="w")

        ctk.CTkFrame(self.sidebar_frame, height=1, fg_color="#2a2a2a").pack(fill="x", padx=15, pady=(0, 10))

        self.song_list_frame = ctk.CTkScrollableFrame(self.sidebar_frame, fg_color="transparent")
        self.song_list_frame.pack(expand=True, fill="both", padx=5, pady=(0, 15))

        # --- 2. MAIN FRAME ---
        self.main_frame = ctk.CTkFrame(self.bg_container, corner_radius=20, fg_color="#1e1e1e")
        self.main_frame.grid_propagate(False)

        self.btn_hamburger = ctk.CTkButton(
            self.main_frame, text="☰", font=ctk.CTkFont(size=24), width=40,
            fg_color="transparent", hover_color="#2a2a2a", text_color="white", command=self.toggle_sidebar
        )
        self.btn_hamburger.place(x=15, y=15)

        self.btn_more = ctk.CTkButton(
            self.main_frame, text="⋮", font=ctk.CTkFont(size=24, weight="bold"), width=40,
            fg_color="transparent", hover_color="#2a2a2a", text_color="white", command=self.open_more_menu
        )
        self.btn_more.place(relx=1.0, x=-15, y=15, anchor="ne")

        self.content_wrapper = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.content_wrapper.place(relx=0.5, rely=0.50, anchor="center") 

        # INFO CONTAINER (Cover, Title, Specs)
        self.info_container = ctk.CTkFrame(self.content_wrapper, fg_color="transparent")
        self.info_container.pack(pady=(0, 10))

        self.album_label = ctk.CTkLabel(self.info_container, text="No Cover Art", text_color="#555555", font=ctk.CTkFont(size=14))
        self.album_label.pack(pady=(0, 20))

        self.track_title = ctk.CTkLabel(self.info_container, text="Belum Ada Lagu", font=ctk.CTkFont(size=26, weight="bold"))
        self.track_title.pack(pady=(0, 2))
        
        self.track_artist = ctk.CTkLabel(self.info_container, text="-", font=ctk.CTkFont(size=15), text_color="#aaaaaa")
        self.track_artist.pack(pady=(0, 5))

        self.quality_badge = ctk.CTkLabel(
            self.info_container, text=" FLAC • -- / -- ", font=ctk.CTkFont(size=10, weight="bold"),
            fg_color="#000", text_color="#888888", corner_radius=10
        )
        self.quality_badge.pack(pady=(0, 15))
        
        # UI SEEK BAR (PROGRESS WAKTU)
        self.time_container = ctk.CTkFrame(self.content_wrapper, fg_color="transparent")
        self.time_container.pack(fill="x", padx=30, pady=(0, 15))
        
        self.label_time_current = ctk.CTkLabel(self.time_container, text="0:00", font=ctk.CTkFont(size=11), text_color="#aaaaaa")
        self.label_time_current.pack(side="left", padx=(0, 10))
        
        self.slider_time = ctk.CTkSlider(
            self.time_container, from_=0, to=100, number_of_steps=1000,
            progress_color="#fa233b", button_color="#ffffff", button_hover_color="#fa233b",
            width=350, height=14, command=self.on_seek_end
        )
        self.slider_time.set(0)
        self.slider_time.pack(side="left", expand=True)
        
        self.label_time_total = ctk.CTkLabel(self.time_container, text="0:00", font=ctk.CTkFont(size=11), text_color="#aaaaaa")
        self.label_time_total.pack(side="left", padx=(10, 0))

        # CONTROL PANEL (Play, Pause, Skip, dll)
        self.control_frame = ctk.CTkFrame(self.content_wrapper, fg_color="transparent")
        self.control_frame.pack(pady=(0, 0))

        self.playback_frame = ctk.CTkFrame(self.control_frame, fg_color="transparent")
        self.playback_frame.pack()

        self.btn_shuffle = ctk.CTkButton(
            self.playback_frame, text="🔀", font=ctk.CTkFont(family="Noto Music", size=24), width=40, 
            fg_color="transparent", hover_color="#2a2a2a", text_color="#555555", command=self.toggle_shuffle
        )
        self.btn_shuffle.grid(row=0, column=0, padx=15)

        self.btn_prev = ctk.CTkButton(
            self.playback_frame, text="⏮", font=ctk.CTkFont(family="Noto Music", size=26), width=40, 
            fg_color="transparent", hover_color="#2a2a2a", text_color="#cccccc", command=self.prev_track
        )
        self.btn_prev.grid(row=0, column=1, padx=15)

        self.btn_play = ctk.CTkButton(
            self.playback_frame, text="▶", font=ctk.CTkFont(family="Noto Music", size=34), width=40, 
            fg_color="transparent", hover_color="#2a2a2a", text_color="white", command=self.play_pause
        )
        self.btn_play.grid(row=0, column=2, padx=15)

        self.btn_next = ctk.CTkButton(
            self.playback_frame, text="⏭", font=ctk.CTkFont(family="Noto Music", size=26), width=40, 
            fg_color="transparent", hover_color="#2a2a2a", text_color="#cccccc", command=self.next_track
        )
        self.btn_next.grid(row=0, column=3, padx=15)

        self.btn_repeat = ctk.CTkButton(
            self.playback_frame, text="🔁", font=ctk.CTkFont(family="Noto Music", size=24), width=40, 
            fg_color="transparent", hover_color="#2a2a2a", text_color="#555555", command=self.toggle_repeat
        )
        self.btn_repeat.grid(row=0, column=4, padx=15)

    def _bind_events(self):
        """Binding event responsif dan seek bar"""
        self.bg_container.bind("<Configure>", self.update_layout)
        self.bind("<Configure>", self.on_window_resize)
        self.slider_time.bind("<ButtonPress-1>", self.on_seek_start)
        if os.name == 'nt':
            self.slider_time.bind("<B1-Motion>", self.on_seek_dragging)

    # ==========================================
    # MEMORI DAN MANAJEMEN FOLDER LOKAL
    # ==========================================
    def save_settings(self, folder_path):
        with open(SETTINGS_FILE, "w") as f:
            json.dump({"last_folder": folder_path}, f)

    def load_settings(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r") as f:
                    last_folder = json.load(f).get("last_folder", "")
                    if last_folder and os.path.exists(last_folder):
                        self.process_folder(last_folder)
            except: pass

    def select_new_folder(self):
        folder_path = ctk.filedialog.askdirectory(title="Pilih Folder Lagu FLAC")
        if folder_path:
            self.process_folder(folder_path)
            self.save_settings(folder_path) 
        self.close_more_menu()

    def process_folder(self, folder_path):
        self.current_playlist_files.clear()
        for widget in self.song_list_frame.winfo_children(): widget.destroy()
        
        try:
            for file in os.listdir(folder_path):
                if file.lower().endswith(".flac"):
                    self.current_playlist_files.append(os.path.join(folder_path, file))
        except Exception: pass

        self.shuffler.set_playlist(len(self.current_playlist_files))

        for index, file_path in enumerate(self.current_playlist_files):
            file_name = os.path.basename(file_path).replace(".flac", "")
            btn = ctk.CTkButton(
                self.song_list_frame, text=f"{index+1}. {file_name}", 
                fg_color="transparent", hover_color="#2a2a2a", text_color="#dddddd",
                anchor="w", font=ctk.CTkFont(size=12), height=35,
                command=lambda i=index: self.play_selected_track(i)
            )
            btn.pack(fill="x", pady=2, padx=2)

    # ==========================================
    # FLOATING MENU (TITIK TIGA)
    # ==========================================
    def open_more_menu(self):
        if self.more_window is not None and self.more_window.winfo_exists():
            self.close_more_menu()
            return

        self.update_idletasks()
        x, y = self.btn_more.winfo_rootx(), self.btn_more.winfo_rooty() + self.btn_more.winfo_height() + 5

        self.more_window = ctk.CTkToplevel(self)
        self.more_window.geometry(f"200x130+{x-160}+{y}")
        self.more_window.overrideredirect(True) 
        self.more_window.attributes("-topmost", True)
        
        more_frame = ctk.CTkFrame(self.more_window, fg_color="#121212", corner_radius=10, border_width=1, border_color="#2a2a2a")
        more_frame.pack(fill="both", expand=True)

        ctk.CTkButton(
            more_frame, text="🎛️ Custom Equalizer", font=ctk.CTkFont(family="Noto Music", size=13),
            fg_color="transparent", border_width=1, border_color="#444", hover_color="#2a2a2a", text_color="white", command=self.open_eq_window
        ).pack(pady=(15, 5), padx=15, fill="x")

        ctk.CTkButton(
            more_frame, text="📂 Load Folder Baru", font=ctk.CTkFont(family="Noto Music", size=13),
            fg_color="transparent", border_width=1, border_color="#444", hover_color="#2a2a2a", text_color="white", command=self.select_new_folder
        ).pack(pady=(5, 15), padx=15, fill="x")

    def close_more_menu(self):
        if self.more_window: self.more_window.destroy()

   # ==========================================
    # STUDIO GRAPHIC EQUALIZER
    # ==========================================
    def open_eq_window(self):
        self.close_more_menu()
        if self.eq_window is not None and self.eq_window.winfo_exists():
            self.eq_window.focus()
            return
            
        self.eq_window = ctk.CTkToplevel(self)
        self.eq_window.title("10-Band Graphic Equalizer")
        self.eq_window.geometry("600x350") 
        self.eq_window.resizable(False, False)
        self.eq_window.attributes("-topmost", True)
        self.eq_window.configure(fg_color="#0a0a0a") 
        
        main_eq_frame = ctk.CTkFrame(self.eq_window, fg_color="transparent")
        main_eq_frame.pack(fill="both", expand=True, padx=15, pady=10)
        
        freqs = ["31", "63", "125", "250", "500", "1k", "2k", "4k", "8k", "16k"]
        self.eq_sliders, self.eq_labels = [], []

        slider_frame = ctk.CTkFrame(main_eq_frame, fg_color="transparent")
        slider_frame.pack(pady=(10, 0))

        for i, freq in enumerate(freqs):
            col_frame = ctk.CTkFrame(slider_frame, fg_color="transparent")
            col_frame.grid(row=0, column=i, padx=6)
            
            ctk.CTkLabel(col_frame, text="+12", font=ctk.CTkFont(size=9), text_color="#555").pack()

            val_label = ctk.CTkLabel(col_frame, text=f"{self.engine.current_eq_amps[i]:.1f}", font=ctk.CTkFont(size=11, weight="bold"), text_color="#fa233b")
            val_label.pack()
            self.eq_labels.append(val_label)
            
            slider = ctk.CTkSlider(
                col_frame, orientation="vertical", from_=-12.0, to=12.0, number_of_steps=240, height=160,
                width=16, progress_color="#444", button_color="#ffffff",
                command=lambda val, idx=i, lbl=val_label: self.on_eq_slider_change(idx, val, lbl)
            )
            slider.set(self.engine.current_eq_amps[i]) 
            slider.pack(pady=5)
            self.eq_sliders.append(slider)
            
            ctk.CTkLabel(col_frame, text="-12", font=ctk.CTkFont(size=9), text_color="#555").pack()
            ctk.CTkLabel(col_frame, text=freq, font=ctk.CTkFont(size=10, weight="bold"), text_color="#aaaaaa").pack(pady=(2, 0))
            
        # FIX: Frame sama Pack dipisah biar tombolnya gak nyasar ke luar angkasa
        bottom_frame = ctk.CTkFrame(main_eq_frame, fg_color="transparent")
        bottom_frame.pack(fill="x", pady=(15, 0))

        btn_reset = ctk.CTkButton(
            bottom_frame, text="🔄 Reset to Flat 0dB", command=self.reset_eq, 
            fg_color="#1a1a1a", hover_color="#2a2a2a", border_width=1, border_color="#333",
            text_color="white", width=180, height=35, corner_radius=16, font=ctk.CTkFont(weight="bold")
        )
        btn_reset.pack(pady=5)

    def on_eq_slider_change(self, index, value, label):
        label.configure(text=f"{value:.1f}")
        self.engine.set_custom_eq(index, float(value))

    def reset_eq(self):
        for i in range(10):
            self.eq_sliders[i].set(0.0)
            self.eq_labels[i].configure(text="0.0")
            self.engine.set_custom_eq(i, 0.0)

    # ==========================================
    # LOGIKA PLAYBACK & SEEKING BAR
    # ==========================================
    def monitor_playback(self):
        if self.is_playing:
            if not self.is_seeking:
                current_ms = self.engine.get_time()
                if self.track_length_ms <= 0:
                    self.track_length_ms = self.engine.get_length()
                    if self.track_length_ms > 0:
                        self.label_time_total.configure(text=self.format_time(self.track_length_ms))
                        self.slider_time.configure(to=self.track_length_ms)
                
                if current_ms >= 0 and self.track_length_ms > 0:
                    self.slider_time.set(current_ms)
                    self.label_time_current.configure(text=self.format_time(current_ms))

            if self.engine.is_finished(): self.next_track(auto_next=True)
        self.after(500, self.monitor_playback)

    def on_seek_start(self, event): self.is_seeking = True
    def on_seek_dragging(self, event):
        if self.track_length_ms > 0:
            self.label_time_current.configure(text=self.format_time(self.slider_time.get()))
    def on_seek_end(self, value):
        if self.track_length_ms > 0: self.engine.set_time(value)
        self.after(100, lambda: setattr(self, 'is_seeking', False))

    def toggle_shuffle(self):
        self.is_shuffle = not self.is_shuffle
        self.btn_shuffle.configure(text_color="#fa233b" if self.is_shuffle else "#555555") 

    def toggle_repeat(self):
        self.repeat_mode = (self.repeat_mode + 1) % 3
        states = [("🔁", "#555555"), ("🔁", "#fa233b"), ("🔂", "#fa233b")]
        self.btn_repeat.configure(text=states[self.repeat_mode][0], text_color=states[self.repeat_mode][1])

    def next_track(self, auto_next=False):
        if not self.current_playlist_files: return
        if self.repeat_mode == 2 and auto_next:
            return self.play_selected_track(self.current_track_index)

        if self.is_shuffle: next_idx = self.shuffler.get_next_index()
        else:
            next_idx = self.current_track_index + 1
            if next_idx >= len(self.current_playlist_files):
                if self.repeat_mode == 1: next_idx = 0 
                elif self.repeat_mode == 0 and auto_next: 
                    self.engine.stop(); self.is_playing = False; self.btn_play.configure(text="▶")
                    self.slider_time.set(0); self.label_time_current.configure(text="0:00")
                    return 
                else: next_idx = 0 
        self.play_selected_track(next_idx)

    def prev_track(self):
        if not self.current_playlist_files: return
        if self.engine.get_time() > 3000: self.engine.set_time(0)
        else: self.play_selected_track((self.current_track_index - 1) % len(self.current_playlist_files))

    def play_selected_track(self, index):
        if index < 0 or index >= len(self.current_playlist_files): return
        self.current_track_index = index
        file_path = self.current_playlist_files[index]
        
        self.track_length_ms = 0
        self.slider_time.set(0)
        self.label_time_current.configure(text="0:00"); self.label_time_total.configure(text="0:00")
        self.slider_time.configure(to=100) 

        self.engine.load_and_play(file_path)
        self.is_playing = True
        self.btn_play.configure(text="⏸")
        
        info = self.engine.extract_metadata(file_path)
        if info:
            self.track_title.configure(text=info['title'])
            self.track_artist.configure(text=info['artist'])
            self.quality_badge.configure(text=f" {info['format']} • {info['bit_depth']}-bit / {info['sample_rate']}kHz ")
            self.set_cover_image(info['cover_bytes'])
            self.main_frame.configure(fg_color=self.extract_dominant_color(info['cover_bytes']))

    def play_pause(self):
        if self.current_track_index == -1: return 
        if self.engine.pause_resume() == "playing":
            self.is_playing = True; self.btn_play.configure(text="⏸")
        else:
            self.is_playing = False; self.btn_play.configure(text="▶")

    def format_time(self, ms):
        return f"{int((ms / (1000 * 60)) % 60)}:{int((ms / 1000) % 60):02d}"

    # ==========================================
    # MESIN BEDAH GAMBAR & RESPONSIVE UI
    # ==========================================
    def extract_dominant_color(self, cover_bytes):
        if not cover_bytes: return "#1e1e1e"
        try:
            img = Image.open(io.BytesIO(cover_bytes)).convert('RGB')
            img.thumbnail((50, 50))
            avg_img = img.resize((1, 1), resample=Image.Resampling.BILINEAR)
            r, g, b = avg_img.getpixel((0, 0))
            
            h, l, s = colorsys.rgb_to_hls(r/255.0, g/255.0, b/255.0)
            tuned_r, tuned_g, tuned_b = colorsys.hls_to_rgb(h, max(0.10, min(l, 0.20)), max(s, 0.5))
            return "#{:02x}{:02x}{:02x}".format(int(tuned_r*255), int(tuned_g*255), int(tuned_b*255))
        except Exception: return "#1e1e1e"

    def set_cover_image(self, cover_bytes):
        base_size = int(280 * self.current_scale)
        if cover_bytes:
            try:
                image_data = Image.open(io.BytesIO(cover_bytes))
                self.cover_img = ctk.CTkImage(light_image=image_data, dark_image=image_data, size=(base_size, base_size))
                self.album_label.configure(image=self.cover_img, text="")
            except Exception: self.album_label.configure(image="", text="Gagal Load")
        else:
            empty_img = Image.new("RGB", (base_size, base_size), color="#2a2a2a")
            self.cover_img = ctk.CTkImage(light_image=empty_img, dark_image=empty_img, size=(base_size, base_size))
            self.album_label.configure(image=self.cover_img, text="No Cover Art")

    def on_window_resize(self, event):
        if event.widget == self:
            if self.resize_timer: self.after_cancel(self.resize_timer)
            self.resize_timer = self.after(150, lambda: self.apply_scaling(event.width, event.height))

    def apply_scaling(self, width, height):
        scale = max(0.8, min(min(width / 850, height / 650), 1.25)) 
        if abs(self.current_scale - scale) < 0.05: return 
        self.current_scale = scale
        
        if hasattr(self, 'cover_img'):
            new_size = int(280 * scale)
            self.cover_img.configure(size=(new_size, new_size))
        
        self.track_title.configure(font=ctk.CTkFont(size=int(26 * scale), weight="bold"))
        self.track_artist.configure(font=ctk.CTkFont(size=int(15 * scale)))
        self.slider_time.configure(width=int(350 * scale))
        
        fonts = {"btn_play": 34, "btn_prev": 26, "btn_next": 26, "btn_shuffle": 24, "btn_repeat": 24}
        for btn, size in fonts.items():
            getattr(self, btn).configure(font=ctk.CTkFont(family="Noto Music", size=int(size * scale)))

    def update_layout(self, event=None):
        container_w = self.bg_container.winfo_width()
        if container_w < 50: return 
        self.sidebar_frame.place(x=self.sidebar_offset, y=0, relheight=1.0)
        main_x = max(0, 260 + self.sidebar_offset)
        self.main_frame.configure(width=container_w - main_x)
        self.main_frame.place(x=main_x, y=0, relheight=1.0)

    def toggle_sidebar(self):
        if self.is_animating: return 
        self.is_animating = True
        if self.sidebar_visible: self.animate_close()
        else: self.animate_open()

    def animate_close(self):
        if self.sidebar_offset > -260:
            self.sidebar_offset -= 20
            self.update_layout()
            self.after(10, self.animate_close)
        else:
            self.sidebar_offset = -260
            self.update_layout(); self.sidebar_visible = False; self.is_animating = False

    def animate_open(self):
        if self.sidebar_offset < 0:
            self.sidebar_offset += 20
            self.update_layout()
            self.after(10, self.animate_open)
        else:
            self.sidebar_offset = 0
            self.update_layout(); self.sidebar_visible = True; self.is_animating = False

if __name__ == "__main__":
    app = AudiophilePlayer()
    app.mainloop()