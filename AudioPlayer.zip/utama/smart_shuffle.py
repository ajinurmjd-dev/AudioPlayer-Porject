import random

class SmartShuffle:
    def __init__(self):
        self.playlist_indices = []
        self.bag = []
        self.last_played = -1

    def set_playlist(self, total_tracks):
        """Masukin jumlah lagu ke dalem memori mesin shuffle"""
        self.playlist_indices = list(range(total_tracks))
        self.reshuffle_bag()

    def reshuffle_bag(self):
        """Nge-reset dan ngacak ulang kantong lagu"""
        self.bag = self.playlist_indices.copy()
        random.shuffle(self.bag)
        
        # Anti-Clash: Pastiin lagu baru gak sama kayak yang baru abis diputer
        if self.bag and self.last_played == self.bag[0] and len(self.bag) > 1:
            self.bag.append(self.bag.pop(0))

    def get_next_index(self):
        """Ambil satu lagu dari kantong"""
        if not self.playlist_indices:
            return -1
        if not self.bag:
            self.reshuffle_bag() 
            
        next_track = self.bag.pop(0)
        self.last_played = next_track
        return next_track